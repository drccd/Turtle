package Turtle;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;	
import java.awt.Polygon;
import java.awt.Graphics;
import java.util.ArrayList;
import java.io.FileWriter;
import java.util.Scanner;


import uk.ac.leedsbeckett.oop.LBUGraphics;


public class GraphicsSystem extends LBUGraphics 
{
	 {
		 JFrame mainFrame = new JFrame("Biraj Shrestha - Turtle System OOP");
	     mainFrame.setLayout(new FlowLayout()); 
	     mainFrame.add(this); 
	
	     MenuBar menuBar = new MenuBar();
	     mainFrame.setJMenuBar(menuBar);
	
	     mainFrame.pack(); 
	     mainFrame.setVisible(true);
	     mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	     displayWelcomeMessage();
	     //about();
	 }
	 
	 
	 	public int savedImage=0;
	
	 	ArrayList<String> allcommands = new ArrayList<>();
	

	 	public BufferedImage getsavedimage() 
	{
	 		
		return this.getBufferedImage();
	}
	 	
	public void setsavedimage(BufferedImage img)
	{
		
		this.setBufferedImage(img);
	}
	
	public void drawTriangle()
	{
		int length = Integer.parseInt(JOptionPane.showInputDialog("Enter the length of the triangle:"));

		clear();
		reset();
		penDown();
		turnLeft(90);
		forward(length);	  
		turnLeft(120);
		forward(length);
		turnLeft(120);
		forward(length);
		reset();
	}
	
	public void triangle(int length1, int length2, int length3) {
	   

	    final int A_X_POS = getxPos();
	    final int A_Y_POS = getyPos();
	    final int B_X_POS = A_X_POS + length1;
	    final int B_Y_POS = A_Y_POS;
	    final int C_X_POS = A_X_POS + ((length1 * length1 + length3 * length3 - length2 * length2) / (2 * length1));
	    final int C_Y_POS = A_Y_POS + (int) (Math.sqrt(length3 * length3 - (C_X_POS - A_X_POS) * (C_X_POS - A_X_POS)));
	    final int[] xPoints = new int[] { A_X_POS, B_X_POS, C_X_POS };
	    final int[] yPoints = new int[] { A_Y_POS, B_Y_POS, C_Y_POS };

	    reset();

	    Polygon tri = new Polygon(xPoints, yPoints, 3);

	    Graphics g = getGraphics2DContext();

	    g.drawPolygon(tri);
	    reset();
	}
	
	public void drawSquare()
	{
		
		int length = Integer.parseInt(JOptionPane.showInputDialog("Enter the length of the square:"));
	    
	    
	    clear();
	    reset();
	    penDown();
	    turnLeft(90);
	    forward(length);
	    turnLeft(90);
	    forward(length);
	    turnLeft(90);
	    forward(length);
	    turnLeft(90);
	    forward(length);
	    reset();
	}
	public void drawPentagon()
	{
		clear();
		reset();
		turnRight(54);
		forward(90);
		turnLeft(72);
		forward(90);
		turnLeft(72);
		forward(90);
		turnLeft(72);
		forward(90);
		turnLeft(72);
		forward(90);
		pointTurtle(180);
	}
	public void drawHexagon()
	{
		clear();
		reset();
		penDown();
		pointTurtle(270);
		forward(90);
		turnLeft(60);
		forward(90);
		turnLeft(60);
		forward(90);
		turnLeft(60);
		forward(90);
		turnLeft(60);
		forward(90);
		turnLeft(60);
		forward(90);
	}
	public void drawKite() 
	{
		clear();
		reset();
		penDown();
		turnRight(90);
		forward(100);	  
		turnRight(120);
		forward(100);
		turnRight(120);
		forward(100);
		turnRight(55);
		forward(110);
		turnRight(126);
		forward(110);
		penUp();
		forward(-110);
		turnRight(29);
		penDown();
		forward(179);
		
	}
	public void drawHeart()
	{
		clear();
		penUp();
		forward(40);
		penDown();
		pointTurtle(90);
		forward(30);
		pointTurtle(135);
		forward(15);
		pointTurtle(45);
		forward(15);
		pointTurtle(90);
		forward(30);
		pointTurtle(150);
		forward(30);
		pointTurtle(225);
		forward(75);
		pointTurtle(315);
		forward(75);
		pointTurtle(30);
		forward(30);

	}
	public void info()
	{
		
		  JOptionPane.showMessageDialog(null,"I recently completed an assignment project that involved creating a turtle graphics code, and it was a great experience!"
								  		+ "\n I was excited to take on the challenge of learning about programming concepts such as loops, functions, and conditionals"
								  		+ "\n while using code to draw shapes and patterns on the screen. As I worked on the project, I was able to bring my code to life "
								  		+ "\n with turtle graphics and see my work come together. It was a great feeling of accomplishment to finish the project, and I'm "
								  		+ "\nproud of what I was able to create. Overall, the project was a valuable learning experience that helped me grow as a programmer.");
	}
	
	public void saveimage()
	{
		try 
	    {
	        String fileName = JOptionPane.showInputDialog("Enter the name of the file:");
	        if (fileName != null) 
	        {
	            File outputFile = new File(fileName + ".png");
	            if (outputFile.exists())
	            {
	                int option = JOptionPane.showConfirmDialog(null,
	                        "File already exists. Do you want to overwrite it?",
	                        "Warning",
	                        JOptionPane.YES_NO_OPTION); 
	                if (option == JOptionPane.NO_OPTION)
	                {
	                    return;
	                }
	            }
	            ImageIO.write(getsavedimage(), "png", outputFile);
	            savedImage = 1;
	            JOptionPane.showMessageDialog(null, "Image saved successfully!");
	        }
	    } catch (IOException e) 
	    
	    {
	        JOptionPane.showMessageDialog(null, "Error: Unable to save the file.");
	    }
	}
	
	public void loadimage()
	{
		try 
	    {
	        String fileName = JOptionPane.showInputDialog("Enter the name of the file:");
	        if (fileName != null) 
	        {
	            File inputFile = new File(fileName + ".png");
	            if (inputFile.exists())
	            {
	                BufferedImage image = ImageIO.read(inputFile);
	                setsavedimage(image);
	                repaint();
	                JOptionPane.showMessageDialog(null, "Image loaded successfully!");
	            } else {
	                JOptionPane.showMessageDialog(null, "Error: File does not exist.");
	            }
	        }
	    } catch (IOException e)
	    {
	        JOptionPane.showMessageDialog(null, "Error: Unable to load the file.");
	    }
	}

	public void savecommands() {
	    try {
	        String fileName = JOptionPane.showInputDialog("Enter the name of the file:");
	        if (fileName != null) {
	            File outputFile = new File(fileName + ".txt");
	            if (outputFile.exists()) {
	                int option = JOptionPane.showConfirmDialog(null,
	                        "File already exists. Do you want to overwrite it?",
	                        "Warning",
	                        JOptionPane.YES_NO_OPTION);
	                if (option == JOptionPane.NO_OPTION) {
	                    
	                    return;
	                }
	            }
	            FileWriter myWriter = new FileWriter(outputFile);
	            for (String str : allcommands) {
	                myWriter.write(str + System.lineSeparator());
	            }
	            myWriter.close();
	            savedImage = 0;
	            JOptionPane.showMessageDialog(null, "Commands saved successfully!");
	        }
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(null, "Error: Unable to save the commands.");
	    }
	}
	
	public void loadcommands() {
	    try {
	        String fileName = JOptionPane.showInputDialog("Enter the name of the file:");
	        if (fileName != null) {
	            File comInputFile = new File(fileName + ".txt");
	            if (comInputFile.exists()) {
	                Scanner myReader = new Scanner(comInputFile);
	                while (myReader.hasNextLine()) {
	                    String data = myReader.nextLine();
	                    allcommands.add(data);
	                    String[] parts = data.split(" ");
	                    String command = parts[0].toLowerCase();
	                    int parameter = 0;
	                    if (parts.length > 1) {
	                        try {
	                            parameter = Integer.parseInt(parts[1]);
	                        } catch (NumberFormatException e) {
	                            JOptionPane.showMessageDialog(null, "Error: Invalid parameter.");
	                            return;
	                        }
	                    }
	                    processCommand(command);
	                }
	                myReader.close();
	                displayMessage("Commands loaded successfully!");
	            } else {
	                JOptionPane.showMessageDialog(null, "Error: File does not exist.");
	            }
	        } else {
	            
	            JOptionPane.showMessageDialog(null, "Load operation canceled.");
	        }
	    } catch (IOException e) {
	        JOptionPane.showMessageDialog(null, "Error: Unable to load the commands.");
	    }
	}
	
	public void overrideabout()
	{
		super.about();
		
		
		
		//B
		penUp();
		forward(20);
		penDown();
		pointTurtle(180);
		forward(50);
		pointTurtle(90);
		forward(30);
		pointTurtle(0);
		forward(22);
		pointTurtle(330);
		forward(5);
		pointTurtle(30);
		forward(5);
		pointTurtle(0);
		forward(22);
		pointTurtle(90);
		forward(-30);
		forward(30);
		
		//I
		penUp();
		forward(20);
		penDown();
		pointTurtle(90);

		forward(30);
		forward(-15);
		pointTurtle(180);
		forward(50);
		pointTurtle(90);
		forward(-15);
		forward(30);
		penUp();
		pointTurtle(0);
		forward(50);
		pointTurtle(90);
		penDown();
		
		//R
		penUp();
		forward(20);
		penDown();
		pointTurtle(180);

		forward(50);
		forward(-30);
		pointTurtle(135);
		forward(45);
		forward(-45);
		pointTurtle(90);
		forward(30);
		pointTurtle(0);
		forward(20);
		pointTurtle(90);
		forward(-30);
		forward(30);
		
		//A
		penUp();
		forward(20);
		penDown();
		pointTurtle(180);
		forward(50);
		forward(-50);
		pointTurtle(90);
		forward(30);
		pointTurtle(180);
		forward(50);
		forward(-25);
		pointTurtle(270);
		forward(30);
		forward(-30);
		pointTurtle(0);
		forward(25);
		pointTurtle(90);
		
		penUp();
		forward(20);
		penDown();
		pointTurtle(180);

		//J
		penUp();
		forward(30);
		penDown();
		forward(20);
		pointTurtle(90);
		forward(20);
		pointTurtle(0);
		forward(50);
		pointTurtle(90);
		forward(-10);
		forward(10);
	}
	
public class MenuBar extends JMenuBar
{
	
    public MenuBar()
    {
    	// file menu
    
        JMenu fileMenu = new JMenu("File");

        JMenuItem saveMenuItem = new JMenuItem("Save");
        saveMenuItem.addActionListener(e -> saveimage());

        JMenuItem loadMenuItem = new JMenuItem("Load");
        loadMenuItem.addActionListener(e -> loadimage());
        
        JMenuItem savecommandsMenuItem = new JMenuItem("SaveCode");
        savecommandsMenuItem.addActionListener(e -> savecommands());

        JMenuItem loadcommandsMenuItem = new JMenuItem("LoadCode");
        loadcommandsMenuItem.addActionListener(e -> loadcommands());

        fileMenu.add(saveMenuItem);
        fileMenu.add(loadMenuItem);
        fileMenu.add(savecommandsMenuItem);
        fileMenu.add(loadcommandsMenuItem);

        add(fileMenu);
        
        // commands menu
        JMenu commandMenu = new JMenu("Commands");
        
        JMenuItem commandMenuItem = new JMenuItem("Command");
        commandMenuItem.addActionListener(e -> displayWelcomeMessage());
        
        commandMenu.add(commandMenuItem);
        add(commandMenu);
        
        // shapes menu
        JMenu shapesMenu = new JMenu("Shapes");
       
        JMenuItem squareMenuItem = new JMenuItem("Square");
        squareMenuItem.addActionListener(e -> drawSquare());

        JMenuItem triangleMenuItem = new JMenuItem("Triangle");
        triangleMenuItem.addActionListener(e -> drawTriangle());
        
        JMenuItem pentagonMenuItem = new JMenuItem("Pentagon");
        pentagonMenuItem.addActionListener(e -> drawPentagon());
        
        JMenuItem hexagonMenuItem = new JMenuItem("Hexagon");
        hexagonMenuItem.addActionListener(e -> drawHexagon());
        
        JMenuItem heartMenuItem = new JMenuItem("Heart");
        heartMenuItem.addActionListener(e -> drawHeart());
        
        JMenuItem kiteMenuItem = new JMenuItem("Kite");
        kiteMenuItem.addActionListener(e -> drawKite());

        shapesMenu.add(squareMenuItem);
        shapesMenu.add(triangleMenuItem);
        shapesMenu.add(pentagonMenuItem);
        shapesMenu.add(hexagonMenuItem);
        shapesMenu.add(heartMenuItem);
        shapesMenu.add(kiteMenuItem);
        add(shapesMenu);
        
        // colors menu
        JMenu colorsMenu = new JMenu("Colors");

        JMenuItem redMenuItem = new JMenuItem("Red");
        redMenuItem.addActionListener(e -> setPenColour(Color.RED));

        JMenuItem blueMenuItem = new JMenuItem("Blue");
        blueMenuItem.addActionListener(e -> setPenColour(Color.BLUE));

        JMenuItem greenMenuItem = new JMenuItem("Green");
        greenMenuItem.addActionListener(e -> setPenColour(Color.GREEN));

        JMenuItem blackMenuItem = new JMenuItem("Black");
        blackMenuItem.addActionListener(e -> setPenColour(Color.BLACK));
        
        JMenuItem pinkMenuItem = new JMenuItem("Pink");
        pinkMenuItem.addActionListener(e -> setPenColour(Color.PINK));

        JMenuItem whiteMenuItem = new JMenuItem("White");
        whiteMenuItem.addActionListener(e -> setPenColour (Color.WHITE));

        colorsMenu.add(redMenuItem);
        colorsMenu.add(blueMenuItem);
        colorsMenu.add(greenMenuItem);
        colorsMenu.add(blackMenuItem);
        colorsMenu.add(pinkMenuItem);
        colorsMenu.add(whiteMenuItem);
        add(colorsMenu);
       
        // Options menu
        JMenu optionsMenu = new JMenu("Options");

        JMenuItem resetMenuItem = new JMenuItem("Reset");
        resetMenuItem.addActionListener(e -> reset());

        JMenuItem newMenuItem = new JMenuItem("New");
        newMenuItem.addActionListener(e -> clear());

        optionsMenu.add(resetMenuItem);
        optionsMenu.add(newMenuItem);

        add(optionsMenu);
        
        //about menu
        JMenu aboutMenu = new JMenu("About");
        
        JMenuItem aboutMenuItem = new JMenuItem("About");
        aboutMenuItem.addActionListener(e -> info());
        
        aboutMenu.add(aboutMenuItem);
        add(aboutMenu);
        
    }
}

	public void RGB(int redvalue, int greenvalue, int bluevalue) 
	{
		Color rgbColor = new Color(redvalue, greenvalue, bluevalue);
		setPenColour(rgbColor);
	}


private void displayWelcomeMessage()
	{
	    displayMessage("Biraj Shrestha");
	  
	    JOptionPane.showMessageDialog(null,
	            "Welcome to Biraj's Turtle Graphics. Please enter the commands given below:\n\n" +
	                    "Commands:\n" +
	                    "Move Forward: Forward x\n" +
	                    "Move Backward: Backward x\n" +
	                    "Rotate 90 degrees right: turnright\n" +
	                    "Rotate 90 degrees left: turnleft\n" +
	                    "Rotate 360 degrees: circle\n" +
	                    "Colorpen off: pendown\n" +
	                    "Colorpen on: penup\n" +
	                    "Change pencolor: color\n" +
	                    "Change penwidth: width\n" +
	                    "Save Image: Save\n" +
	                    "Load Existing: Load\n" +
	                    "Reset turtle's position: Reset\n" +
	                    "Clear drawings: New");
	   
	}


    public void processCommand(String commandLine)
    {
        String[] parts = commandLine.split(" ");
        String command = parts[0].toLowerCase();
        int parameter = 0;
        allcommands.add(command);

        if (parts.length > 1)
        {
            try
	            {
	                parameter = Integer.parseInt(parts[1]);
	            } 
            		catch (NumberFormatException e) 
	            {
	                JOptionPane.showMessageDialog(null, "Error: Invalid parameter.");
	                return;
	            }
        }

        switch (command) 
        {
        case "penup":
    		
    			this.penUp();
    			savedImage = 0;
    		
    		break;
    		
    	case "pendown":
    		
    	
    			this.penDown();
    			savedImage = 0;
    	
    		break;
    		
    	case "turnleft":
    		if(parameter <= 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.turnLeft(parameter);
    			savedImage = 0;
    		}
    		break;
    		
    	case "turnright":
    		if(parameter <= 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.turnRight(parameter);
    			savedImage = 0;
    		}
    		break;
    		
    	case "forward":
    		if(parameter <= 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.forward(parameter);
    			savedImage = 0;
    		}
    		break;
    		
    	case "backward":
    		if(parameter <= 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.forward(-1 * parameter);
    			savedImage = 0;
    		}
    		break;
    		
    	case "circle":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			int length = Integer.parseInt(JOptionPane.showInputDialog("Enter the length of the square:"));
    		    
    			this.circle(length);
    			savedImage = 0;
    		}
    		break;
    		
    	case "triangle":
    		
    		 if (parts.length == 1) 
    		{
    			drawTriangle();
    		}
    		else if (parts.length == 4)
    		{
    			triangle(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
    		}
    		else
   		  {
   		    JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
   		  }
    		break;
    		
    		  	  
    	case "square":
    		  if(parameter != 0) {
    		    JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		  } else {
    		    drawSquare();
    		    savedImage = 0;
    		  }
    		  break;
    		  
    	case "pentagon":
    		  if(parameter != 0) {
    		    JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		  } else {
    		    drawPentagon();
    		    savedImage = 0;
    		  }
    		  break;
    		  
    	case "hexagon":
    		  if(parameter != 0) {
    		    JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		  } else {
    		    drawHexagon();
    		    savedImage = 0;
    		  }
    		  break;
    		  
    	case "kite":
    		  if(parameter != 0) {
    		    JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		  } else {
    		    drawKite();
    		    savedImage = 0;
    		  }
    		  break;
    	case "heart":
  		  if(parameter != 0) {
  		    JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
  		  } else {
  		    drawHeart();
  		    savedImage = 0;
  		  }
  		  break;
  		  
    		
    	case "red":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.setPenColour(Color.RED);
    			displayMessage("Now using colour red");
    			savedImage = 0;
    		}
    		break;
    		
    	case "blue":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.setPenColour(Color.BLUE);
    			displayMessage("Now using colour blue");
    			savedImage = 0;
    		}
    		break;
    		
    	case "green":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.setPenColour(Color.GREEN);
    			displayMessage("Now using colour green");
    			savedImage = 0;
    		}
    		break;

    	case "pink":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.setPenColour(Color.PINK);
    			displayMessage("Now using colour pink");
    			savedImage = 0;
    		}
    		break;
    	case "white":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.setPenColour(Color.WHITE);
    			displayMessage("Now using colour white");
    			savedImage = 0;
    		}
    		break;
    		
    	case "rgb":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else 
    		{
    		RGB(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
    		savedImage = 0;
    		}
    		break;
    		
    	case "width":
    		if(parameter < 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
			setStroke(parameter);
    		}
			break;
    		
    		
    	case "about":  		
    		if(parameter != 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			about();

    		}
    		break;
    		
    	case "overrideabout":  		
    		if(parameter != 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			overrideabout();

    		}
    		break;
    		
    	case "reset":
    		savedImage = 1;
    		if(parameter != 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.reset();
    			displayMessage("The turtle has been reset");
    		}
    		break;
    		
    	case "new":
    		savedImage = 1;
    		if(parameter != 0)
    		{
    			JOptionPane.showMessageDialog(null, "You have entered invalid parameters");
    		}
    		else
    		{
    			this.clear();
    		}
    		break;
    
    	case "save":
    	    saveimage();
    	    break;
    	    

    	case "load":
    	    loadimage();
    	    break;
    	    
    	case "savecode":
    	    savecommands();
    	    break;
    	    
    	case "loadcode":
    	    loadcommands();
    	    break;
    	    
    	case "evolve":
            
			setTurtleImage("turtle2.png");
			penUp();
			forward(1);
			forward(-1);
			penDown();
			turnRight(90);
			displayMessage("The turtle has evolved");
			break;
	
    	
    	default:
			JOptionPane.showMessageDialog(null, "Error: Invalid command.");
			break;     
        }
    }	
}


